const pauseBtn = document.getElementById("pauseBtn");
const message = document.getElementById("controlMessage");
pauseBtn.addEventListener("click", async () => {
  try {
    const res = await fetch("/api/toggle", {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({enabled:false})
    });
    const data = await res.json();
    message.textContent = data.message || "Bot remains paused.";
  } catch (e) {
    message.textContent = "Dashboard API unavailable. Bot is not connected.";
  }
});

let installPrompt = null;
const installBtn = document.getElementById("installBtn");
window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  installPrompt = event;
  if (installBtn) installBtn.hidden = false;
});
if (installBtn) {
  installBtn.addEventListener("click", async () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    await installPrompt.userChoice;
    installPrompt = null;
    installBtn.hidden = true;
  });
}
